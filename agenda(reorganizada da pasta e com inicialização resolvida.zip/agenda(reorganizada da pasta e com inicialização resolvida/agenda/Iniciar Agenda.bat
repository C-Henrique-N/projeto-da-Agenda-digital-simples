
@echo off
cd /d "%~dp0"

start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000/dashboard"

py manage.py runserver

pause
